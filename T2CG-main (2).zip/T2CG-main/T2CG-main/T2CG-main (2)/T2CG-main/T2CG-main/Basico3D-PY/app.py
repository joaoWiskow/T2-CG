# OpenGLBasico3D-V5.py - Versão adaptada (cores e mover para frente)
# Autor: adaptado por ChatGPT
import sys
import os
import time
import random as ALE
from math import sin, cos, radians, sqrt

from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

# -------------------- utilidades mínimas pra não depender de módulos externos
class Ponto:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
    def imprime(self, label=""):
        print(label, f"({self.x:.2f},{self.y:.2f},{self.z:.2f})")

# cores básicas (também usadas para overlay)
White = (1.0,1.0,1.0)
Black = (0.0,0.0,0.0)
Red = (1.0,0.0,0.0)
Green = (0.0,1.0,0.0)
Blue = (0.0,0.0,1.0)
Yellow = (1.0,1.0,0.0)
# Tons marrons solicitados
BrownFloor = (0.45,0.25,0.07)   # piso marrom
BrownWall = (0.36,0.25,0.20)    # paredes marrom
Wood = (0.6,0.3,0.2)

# defineCor usado nas rotinas de texto 2D
def defineCor(c):
    glColor3f(c[0], c[1], c[2])

# -------------------- constantes do mundo
ALTURA_PAREDE = 2.7
ESPESSURA_PAREDE = 0.25
ALTURA_PORTA = 2.10
ALTURA_JANELA_BASE = 0.9

# tipos de celula no mapa (inteiros/caracteres)
CELL_EMPTY = 0
CELL_WALL_H = 1
CELL_WALL_V = 2
CELL_PLAYER = 'P'
CELL_FIXED = 'F'
CELL_WINDOW = 'J'
CELL_DOOR = 'D'

# limites
MAX_DIM = 100  # m

# velocidades (m/s)
PLAYER_SPEED = 10.0
ENEMY_SPEED = 20.0

# -------------------- estado global
Cidade = []  # matriz de inteiros/char
QtdX = 0
QtdZ = 0

Observador = Ponto()
Alvo = Ponto()
TerceiraPessoa = Ponto()
PosicaoVeiculo = Ponto()

# modos de visualização
modo_primeira_pessoa = True
modo_terceira_focar_centro = True

# entidades
class Player:
    def __init__(self, x=0.5, z=0.5):
        self.x = x
        self.z = z
        self.y = 0.0
        self.angle = 0.0  # graus, 0 = +x
        self.moving = False
        self.energy = 100.0
        self.score = 0

    def forward_vector(self):
        # vector frente do jogador: ajustado para o sistema de coordenadas usado
        a = radians(self.angle)
        # vx = cos(angle), vz = -sin(angle) para que angle=0 => movimento +x
        return cos(a), -sin(a)

player = Player()

class Enemy:
    def __init__(self, x,z):
        self.x = x
        self.z = z
        self.y = 0.0
    def pos(self):
        return (self.x,self.z)

enemies = []
energies = []  # positions of energy capsules [(x,z),...]
fixed_objects = []  # fixed object positions defined by map

# mapa de janelas (z,x)->altura
mapa_janelas = {}

# timer
oldTime = time.time()

# -------------------- funções de I/O do mapa

def load_map_from_file(filename):
    global Cidade, QtdX, QtdZ, mapa_janelas, fixed_objects
    if not os.path.exists(filename):
        print(f"Arquivo {filename} nao encontrado — usando mapa embedido.")
        return False
    mat = []
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = [p.strip() for p in line.replace(',', ' ').split()]
            row = []
            for p in parts:
                try:
                    v = int(p)
                except:
                    v = p
                row.append(v)
            mat.append(row)
    if len(mat)==0:
        print("Mapa vazio no arquivo.")
        return False
    if len(mat) > MAX_DIM or len(mat[0]) > MAX_DIM:
        print("Mapa excede dimensao maxima de", MAX_DIM)
        return False
    Cidade = mat
    QtdZ = len(Cidade)
    QtdX = len(Cidade[0])
    fixed_objects = []
    mapa_janelas = {}
    for z in range(QtdZ):
        for x in range(QtdX):
            v = Cidade[z][x]
            if v == CELL_FIXED or v == 'F':
                fixed_objects.append((x,z))
            if v == CELL_WINDOW or v == 'J':
                if isinstance(v, str) and ':' in v:
                    try:
                        h = float(v.split(':',1)[1])
                    except:
                        h = 1.0
                    mapa_janelas[(z,x)] = h
                else:
                    mapa_janelas[(z,x)] = 1.0
            if v == CELL_PLAYER or v == 'P':
                player.x = x+0.5
                player.z = z+0.5
    print(f"Mapa carregado: {QtdX}x{QtdZ}")
    return True

# fallback: mapa embutido (20x20 com caminhos)
embedded_map = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,2],
    [2,0,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1,1,0,2],
    [2,0,1,0,0,0,1,0,1,0,1,0,0,0,0,0,0,1,0,2],
    [2,0,1,0,1,0,1,0,1,0,1,0,1,1,1,1,0,1,0,2],
    [2,0,1,0,1,0,1,0,0,0,1,0,1,0,0,1,0,1,'J',2],
    [2,0,1,0,1,0,1,1,1,1,1,0,1,0,'F',1,0,1,0,2],
    [2,0,1,0,1,0,0,0,0,0,0,0,1,0,0,1,0,1,0,2],
    [2,0,1,0,1,1,1,1,1,1,1,0,1,1,0,1,0,1,0,2],
    [2,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,1,0,2],
    [2,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,0,1,0,2],
    [2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1,0,2],
    [2,0,1,1,1,1,1,0,1,1,1,1,1,1,0,1,0,1,0,2],
    [2,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,0,2],
    [2,0,1,0,1,0,1,1,1,1,1,1,0,1,0,1,1,1,0,2],
    [2,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,'F',0,2],
    [2,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,0,1,0,2],
    [2,0,0,0,0,0,0,'J',0,0,0,0,0,0,0,1,0,0,'P',2],
    [2,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,2],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

# -------------------- inicializacao da cidade a partir do mapa em Cidade
def CarregaLabirintoFromMatrix(mat):
    global Cidade, QtdX, QtdZ, fixed_objects, mapa_janelas
    Cidade = mat
    QtdZ = len(Cidade)
    QtdX = len(Cidade[0])
    fixed_objects = []
    mapa_janelas = {}
    for z in range(QtdZ):
        for x in range(QtdX):
            v = Cidade[z][x]
            if v == CELL_FIXED or v == 'F':
                fixed_objects.append((x,z))
            if v == CELL_WINDOW or v == 'J':
                mapa_janelas[(z,x)] = 1.0
            if v == CELL_PLAYER or v == 'P':
                player.x = x+0.5
                player.z = z+0.5

# -------------------- desenhar elementos base
def DesenhaLadrilho():
    glBegin(GL_QUADS)
    glNormal3f(0,1,0)
    glVertex3f(-0.5,0,-0.5)
    glVertex3f(-0.5,0,0.5)
    glVertex3f(0.5,0,0.5)
    glVertex3f(0.5,0,-0.5)
    glEnd()

def DesenhaParedeHorizontal():
    # parede marrom escura
    glColor3f(*BrownWall)
    glPushMatrix()
    glTranslatef(0, ALTURA_PAREDE/2.0, 0)
    glScalef(1.0, ALTURA_PAREDE, ESPESSURA_PAREDE)
    glutSolidCube(1)
    glPopMatrix()

def DesenhaParedeVertical():
    # parede marrom escura
    glColor3f(*BrownWall)
    glPushMatrix()
    glTranslatef(0, ALTURA_PAREDE/2.0, 0)
    glScalef(ESPESSURA_PAREDE, ALTURA_PAREDE, 1.0)
    glutSolidCube(1)
    glPopMatrix()

def DesenhaPorta():
    glColor3f(0.45,0.25,0.1)
    glPushMatrix()
    glTranslatef(0, ALTURA_PORTA/2.0, 0)
    glScalef(0.9, ALTURA_PORTA, 0.05)
    glutSolidCube(1)
    glPopMatrix()

def DesenhaJanela(altura):
    glColor3f(0.7,0.85,0.95)
    glPushMatrix()
    glTranslatef(0, ALTURA_JANELA_BASE + altura/2.0, 0)
    glScalef(0.9, altura, 0.05)
    glutSolidCube(1)
    glPopMatrix()

# desenha um humanoide simples para representar o jogador na 3a pessoa
def DesenhaHumano():
    # torso
    glPushMatrix()
    glScalef(0.4,0.7,0.25)
    glutSolidCube(1)
    glPopMatrix()
    # cabeça
    glPushMatrix()
    glTranslatef(0,0.7+0.25,0)
    glutSolidSphere(0.25,12,12)
    glPopMatrix()
    # pernas
    glPushMatrix()
    glTranslatef(-0.15,-0.7,0)
    glScalef(0.15,0.5,0.15)
    glutSolidCube(1)
    glPopMatrix()
    glPushMatrix()
    glTranslatef(0.15,-0.7,0)
    glScalef(0.15,0.5,0.15)
    glutSolidCube(1)
    glPopMatrix()

def DesenhaInimigo():
    glutSolidSphere(0.3,12,12)

def DesenhaEnergia():
    glPushMatrix()
    glutSolidSphere(0.2,10,10)
    glPopMatrix()

# -------------------- desenho da cidade no mundo
def DesenhaCidade():
    for z in range(QtdZ):
        for x in range(QtdX):
            glPushMatrix()
            glTranslatef(x, 0, z)
            # piso (marrom)
            glColor3f(*BrownFloor)
            DesenhaLadrilho()
            cell = Cidade[z][x]
            if cell == CELL_WALL_H or cell == 1:
                DesenhaParedeHorizontal()
            elif cell == CELL_WALL_V or cell == 2:
                DesenhaParedeVertical()
            elif cell == CELL_DOOR or cell == 'D':
                DesenhaPorta()
            elif cell == CELL_WINDOW or cell == 'J':
                h = mapa_janelas.get((z,x),1.0)
                DesenhaJanela(h)
            elif cell == CELL_FIXED or cell == 'F':
                glPushMatrix()
                glTranslatef(0,0.25,0)
                glColor3f(*Wood)
                DesenhaObjetoFixo()
                glPopMatrix()
            glPopMatrix()

def DesenhaObjetoFixo():
    glutSolidCube(0.5)

# -------------------- utilitario de celula livre
def is_cell_walkable(x,z):
    # aceita índices inteiros
    if x < 0 or z < 0 or x >= QtdX or z >= QtdZ:
        return False
    v = Cidade[z][x]
    # consideramos walkable se for 0 ou P ou F (fixos são tratados mas ocupam a celula)
    if v == 0 or v == CELL_PLAYER or v == CELL_FIXED or v == 'P' or v == 'F':
        return True
    return False

# -------------------- spawn aleatorio de inimigos e capsulas
def spawn_random_entities(n_enemies=10, n_energies=10):
    enemies.clear()
    energies.clear()
    free_cells = [(x,z) for z in range(QtdZ) for x in range(QtdX) if is_cell_walkable(x,z) and not (abs(x+0.5-player.x)<0.1 and abs(z+0.5-player.z)<0.1)]
    ALE.shuffle(free_cells)
    for i in range(min(n_enemies, len(free_cells))):
        x,z = free_cells.pop()
        enemies.append(Enemy(x+0.5, z+0.5))
    for i in range(min(n_energies, len(free_cells))):
        x,z = free_cells.pop()
        energies.append([x+0.5, z+0.5])

# -------------------- fisica simples / movimentacao
def step_simulation(dt):
    # player movement (movimento contínuo quando ligado)
    if player.moving and player.energy > 0:
        vx, vz = player.forward_vector()
        nx = player.x + vx * PLAYER_SPEED * dt
        nz = player.z + vz * PLAYER_SPEED * dt
        if not collides_with_wall(nx, nz):
            player.x = nx
            player.z = nz
            # consome energia proporcional à distancia
            player.energy -= PLAYER_SPEED * dt * 0.5  # fator de consumo arbitrario
            if player.energy < 0:
                player.energy = 0
        else:
            # colisao -> parar movimento
            player.moving = False

    # enemies chase player
    for e in enemies:
        dx = player.x - e.x
        dz = player.z - e.z
        dist = sqrt(dx*dx + dz*dz)
        if dist > 0.001:
            vx = dx/dist
            vz = dz/dist
            nx = e.x + vx * ENEMY_SPEED * dt
            nz = e.z + vz * ENEMY_SPEED * dt
            # verifica colisao com parede
            if not collides_with_wall(nx, nz):
                e.x = nx
                e.z = nz
            else:
                # tenta pequeno desvio lateral
                e.x += -vz * ENEMY_SPEED * dt * 0.5
                e.z += vx * ENEMY_SPEED * dt * 0.5

    # colisões com inimigos
    for e in enemies:
        if distance(player.x, player.z, e.x, e.z) < 0.6:
            player.score -= 10
            move_entity_to_free_cell(e)

    # colisões com energies
    for cap in energies:
        if distance(player.x, player.z, cap[0], cap[1]) < 0.6:
            player.energy = min(100.0, player.energy + 50.0)
            player.score += 5
            move_capsule_to_free_cell(cap)

# helper distance
def distance(x1,z1,x2,z2):
    return sqrt((x1-x2)**2 + (z1-z2)**2)

# move enemy to free cell
def move_entity_to_free_cell(e):
    free = [(x,z) for z in range(QtdZ) for x in range(QtdX) if is_cell_walkable(x,z) and distance(x+0.5,z+0.5,player.x,player.z)>2.0]
    if not free:
        return
    x,z = ALE.choice(free)
    e.x = x+0.5
    e.z = z+0.5

# move capsule
def move_capsule_to_free_cell(cap):
    free = [(x,z) for z in range(QtdZ) for x in range(QtdX) if is_cell_walkable(x,z)]
    if not free:
        return
    x,z = ALE.choice(free)
    cap[0] = x+0.5
    cap[1] = z+0.5

# collide with wall: uses player's center point
def collides_with_wall(cx, cz):
    ix = int(cx)
    iz = int(cz)
    if ix < 0 or iz < 0 or ix >= QtdX or iz >= QtdZ:
        return True
    cell = Cidade[iz][ix]
    if cell == 0 or cell == CELL_PLAYER or cell == CELL_FIXED or cell == 'P' or cell == 'F':
        return False
    if cell == CELL_DOOR or cell == 'D':
        return False
    return True

# -------------------- OpenGL: camera, luz e display
Angulo = 0.0
AlturaViewportDeMensagens = 0.18
AnguloDeVisao = 60.0
AspectRatio = 1.0

def DefineLuz():
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    amb = [0.3,0.3,0.3,1.0]
    dif = [0.7,0.7,0.7,1.0]
    spec = [1.0,1.0,1.0,1.0]
    pos = [player.x, 5.0, player.z, 1.0]
    glLightfv(GL_LIGHT0, GL_AMBIENT, amb)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, dif)
    glLightfv(GL_LIGHT0, GL_SPECULAR, spec)
    glLightfv(GL_LIGHT0, GL_POSITION, pos)

def PosicUser():
    w = glutGet(GLUT_WINDOW_WIDTH)
    h = glutGet(GLUT_WINDOW_HEIGHT)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    global AspectRatio
    AspectRatio = w/h if h!=0 else 1
    gluPerspective(AnguloDeVisao, AspectRatio, 0.01, 500)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    if modo_primeira_pessoa:
        # camera na cabeça do jogador (coerente com forward_vector)
        a = radians(player.angle)
        dx = cos(a)
        dz = -sin(a)
        eye_x = player.x
        eye_y = 1.5
        eye_z = player.z
        center_x = eye_x + dx
        center_y = 1.5
        center_z = eye_z + dz
        gluLookAt(eye_x, eye_y, eye_z, center_x, center_y, center_z, 0,1,0)
    else:
        # terceira pessoa acima do labirinto
        camY = max(QtdX,QtdZ) * 1.2
        camX = QtdX/2.0
        camZ = QtdZ/2.0
        if modo_terceira_focar_centro:
            tgtX = QtdX/2.0
            tgtZ = QtdZ/2.0
        else:
            tgtX = player.x
            tgtZ = player.z
        gluLookAt(camX, camY, camZ, tgtX, 0, tgtZ, 0,0,-1)

# 2D overlay
def DesenhaEm2D():
    ativar_luz = False
    if glIsEnabled(GL_LIGHTING):
        glDisable(GL_LIGHTING)
        ativar_luz = True
    w = glutGet(GLUT_WINDOW_WIDTH)
    h = glutGet(GLUT_WINDOW_HEIGHT)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glViewport(0, 0, w, int(h*AlturaViewportDeMensagens))
    glOrtho(0,10,0,10,-1,1)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    defineCor(White)
    PrintString(f"Energia: {player.energy:.0f}  Score: {player.score}", 0.2, 8.0, White)
    PrintString(f"Modo: {'1P' if modo_primeira_pessoa else '3P'}  Movimento: {'ON' if player.moving else 'OFF'}", 0.2, 6.5, White)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glViewport(0, int(h*AlturaViewportDeMensagens), w, int(h - h*AlturaViewportDeMensagens))
    if ativar_luz:
        glEnable(GL_LIGHTING)

# texto raster
def PrintString(S, x, y, cor):
    defineCor(cor)
    glRasterPos2f(x,y)
    for c in S:
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, ord(c))

# display
def display():
    global Angulo
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    DefineLuz()
    PosicUser()
    glMatrixMode(GL_MODELVIEW)
    # desenha cena
    DesenhaCidade()
    # desenha jogador se terceira pessoa (azul)
    if not modo_primeira_pessoa:
        glPushMatrix()
        glTranslatef(player.x, 0, player.z)
        glRotatef(-player.angle+90, 0,1,0)
        glColor3f(*Blue)   # jogador em azul
        DesenhaHumano()
        glPopMatrix()
    # desenha inimigos (vermelho)
    glColor3f(*Red)
    for e in enemies:
        glPushMatrix()
        glTranslatef(e.x, 0.3, e.z)
        DesenhaInimigo()
        glPopMatrix()
    # desenha capsulas (amarelo)
    glColor3f(*Yellow)
    for cap in energies:
        glPushMatrix()
        glTranslatef(cap[0], 0.2, cap[1])
        DesenhaEnergia()
        glPopMatrix()
    DesenhaEm2D()
    glutSwapBuffers()

# -------------------- loop e tempo
nFrames = 0
AccumDeltaT = 0

def animate():
    global oldTime, AccumDeltaT
    now = time.time()
    dt = now - oldTime
    oldTime = now
    AccumDeltaT += dt
    step_simulation(dt)
    glutPostRedisplay()

# -------------------- input
ESCAPE = b'\x1b'

# adiciona função para passo único para frente (mover para frente direto)
def move_forward_step(step=0.5):
    vx, vz = player.forward_vector()
    nx = player.x + vx * step
    nz = player.z + vz * step
    if not collides_with_wall(nx, nz):
        player.x = nx
        player.z = nz

def keyboard(key, x, y):
    global modo_primeira_pessoa, modo_terceira_focar_centro
    if key == ESCAPE:
        os._exit(0)
    if key == b' ':
        # alterna movimento automático pra frente
        player.moving = not player.moving
    if key == b'v' or key == b'V':
        modo_primeira_pessoa = not modo_primeira_pessoa
    if key == b'c' or key == b'C':
        modo_terceira_focar_centro = not modo_terceira_focar_centro
    # mover um passo para frente (controle direto solicitado)
    if key == b'w' or key == b'W':
        move_forward_step(step=0.5)
    # recarregar energia rápida (útil para testes) - opcional: 'e'
    if key == b'e' or key == b'E':
        player.energy = 100.0
    glutPostRedisplay()

# setas: gira jogador
def arrow_keys(a_keys, x, y):
    if a_keys == GLUT_KEY_LEFT:
        player.angle += 5.0
    if a_keys == GLUT_KEY_RIGHT:
        player.angle -= 5.0
    glutPostRedisplay()

# -------------------- helpers para init
def initialize_opengl():
    glClearColor(0.2,0.5,0.8,1.0)
    glEnable(GL_DEPTH_TEST)
    glShadeModel(GL_SMOOTH)
    glEnable(GL_NORMALIZE)

# -------------------- main
def main():
    global QtdX, QtdZ
    ok = load_map_from_file('mapa.txt')
    if not ok:
        CarregaLabirintoFromMatrix(embedded_map)
    spawn_random_entities(12,12)
    TerceiraPessoa.x = QtdX/2.0
    TerceiraPessoa.y = 10
    TerceiraPessoa.z = QtdZ/2.0
    PosicaoVeiculo.x = QtdX/2.0
    PosicaoVeiculo.y = 0
    PosicaoVeiculo.z = QtdZ/2.0
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)
    glutInitWindowSize(1000,700)
    glutCreateWindow(b"Labirinto - Trabalho OpenGL")
    initialize_opengl()
    glutDisplayFunc(display)
    glutIdleFunc(animate)
    glutKeyboardFunc(keyboard)
    glutSpecialFunc(arrow_keys)
    glutMainLoop()

if __name__ == '__main__':
    main()
